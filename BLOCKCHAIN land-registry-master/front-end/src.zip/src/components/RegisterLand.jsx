import React, { useState } from 'react'
import '../css/RegisterLand.css'

const RegisterLand = (props) => {

  const { provider, web3, contract } = props.myWeb3Api;
  const account = props.account;

  const [landDetails, setLandDetials] = useState({
    name: "", location: "", state: "", district: "", city: "", propertyId: "", surveyNo: "", owner: "", marketValue: "", size: ""
  })

  const onChangeFunc = (event) => {
    const { name, value } = event.target;
    setLandDetials({ ...landDetails, [name]: value });
  }

  const handleOnClick = async () => {
    await contract.registerLand(landDetails.name, landDetails.location, landDetails.state, landDetails.district, landDetails.city, landDetails.propertyId, landDetails.surveyNo, landDetails.owner, landDetails.marketValue, landDetails.size, {
      from: account
    })
    console.log(landDetails)
    setLandDetials({ name: "", location: "", state: "", district: "", city: "", propertyId: "", surveyNo: "", owner: "", marketValue: "", size: "" })
  }



  return (
    <div className='container registerLand-maindiv'>
      <div className='row'>

        {/* left form */}
        <div className='col-12 col-sm-6'>
          <form method='POST' className='admin-form'>
            <div className='form-group'>
              <label>Registrations Type</label>
              <select className="form-control" name="name" value={landDetails.name} onChange={onChangeFunc} required>
                <option value="">Select Registration Type</option>
                <option value="Sale Deed">Sale Deed</option>
                <option value="Gift Deed">Gift Deed</option>
                <option value="Partition Deed">Partition Deed</option>
                <option value="Lease Deed">Lease Deed</option>
                <option value="Mortgage Deed">Mortgage Deed</option>
                <option value="Release Deed">Release Deed</option>
                <option value="Will">Will</option>
              </select>
            </div>
            <div className='form-group'>
              <label>State</label>
              <input type="text" className="form-control" name="state" placeholder="Enter State"
                autoComplete="off" value={landDetails.state} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>District</label>
              <input type="text" className="form-control" name="district" placeholder="Enter district"
                autoComplete="off" value={landDetails.district} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>City</label>
              <input type="text" className="form-control" name="city" placeholder="Enter city"
                autoComplete="off" value={landDetails.city} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>Property ID</label>
              <input type="number" className="form-control" name="propertyId" placeholder="Enter property ID"
                autoComplete="off" value={landDetails.propertyId} onChange={onChangeFunc} />
            </div>
          </form>
        </div>

        {/* right form */}
        <div className='col-12 col-sm-6'>
          <form method='POST' className='admin-form'>
            <div className='form-group'>
              <label>Katha Number</label>
              <input type="number" className="form-control" name="surveyNo" placeholder="Enter Katha number"
                autoComplete="off" value={landDetails.surveyNo} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>Land Location</label>
              <input type="text" className="form-control" name="location" placeholder="Enter land location"
                autoComplete="off" value={landDetails.location} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>Owner Blockchain Address</label>
              <input type="text" className="form-control" name="owner" placeholder="Enter owner blockchain address"
                autoComplete="off" value={landDetails.owner} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>Market Value</label>
              <input type="number" className="form-control" name="marketValue" placeholder="Enter market value"
                autoComplete="off" value={landDetails.marketValue} onChange={onChangeFunc} />
            </div>
            <div className='form-group'>
              <label>Size</label>
              <input type="number" className="form-control" name="size" placeholder="Enter size (sq. ft.)"
                autoComplete="off" value={landDetails.size} onChange={onChangeFunc} />
            </div>
          </form>
        </div>
      </div>
      <button className='admin-form-btn' onClick={handleOnClick}>Submit</button>
    </div>
  )
}

export default RegisterLand